Bonjour {{ P.getGeneric }}

Bienvenu dans la foire {{ App.currentYear }}  dont voici les modalités dans les grandes lignes.

### Préalable
Si vous ne possédez pas de compte ENT de l'université Paris Cité, merci de contacter la [foire](mailto:{{App.appMail}}) afin d'obtenir un accès provisoire.

### Étape 1, le panier : du {{ App.texte.debutPanier }} au {{ App.texte.debutVoeux}}
**Vous devez** :
-  lire la [procédure](http://foire.physique.univ-paris-diderot.fr/foire/texte/procedure) et les règles d'attribution pour les [permanents](http://foire.physique.univ-paris-diderot.fr/foire/texte/regles) et les [non permanents](http://foire.physique.univ-paris-diderot.fr/foire/texte/non-permanents) ; 
- compléter et mettre à jour votre fiche personnelle (coordonnées, situation et photo)
- vérifier que les informations sur votre situation personnelle sont à jour (voir sous votre photo, "statut", décharges pour prises de responsabilités PCC/PCA, délagations, IUF, CRCT, autres)
- explorer les enseignements et les syllabus ;
- contacter les [responsables de filières](http://foire.physique.univ-paris-diderot.fr/foire/texte/adresses) si besoin ;
- **constituer votre panier** avec les enseignements qui a priori vous intéresseraient (il ne s'agit pas des vœux !).
    - le panier doit indiquer vos envies pour l'enseignement, indépendamment des disponibilités au sein des équipes d'enseignement.
    - le panier sera utilisé par la foire et par les responsables des diplomes après la phase des voeux pour résoudre les conflits et pouvoir proposer des solutions les plus adaptées aux envies de chacun.
    - soyez exhaustifs pour faciliter les phases suivantes.
 
À ce stade, seuls les enseignements pour lesquels vous êtes prioritaires apparaissent dans votre tableau de service.

###Étape 2, les vœux : du {{ App.texte.debutVoeux }} au {{ App.texte.limiteVoeux}}
**Vous devez faire vos voeux** et : 
- il n'y a **pas de priorité premier arrivé, premier servi** ;
- le service de référence pour l'année {{ App.currentYear }} - {{ App.currentYear+ 1 }} est {{ App.texte.chargeReference }} hTD ;
- on peut moduler son service dans une fourchette de +/-40hTD, la différence avec le service de référence sera reportée sur le service de {{ App.currentYear+1}} - {{ App.currentYear+ 2 }} ;
- les vœux au-delà du service maximum seront automatiquement annulés par la foire sans vous consulter.

Toutes les règles de la foire sont précisées sur le site de la foire pour les [permanents](http://foire.physique.univ-paris-diderot.fr/foire/texte/regles) et les [non permanents](http://foire.physique.univ-paris-diderot.fr/foire/texte/non-permanents) .

###Étape 3, l'attente : du {{ App.texte.debutDiagonalisation }} au {{App.texte.finDiagonalisation }}
[Les responsables de la foire et des filières](http://foire.physique.univ-paris-diderot.fr/foire/texte/adresses) travailleront pour réaliser vos vœux autant que faire se peut.

###Étape 4, fin de la foire du {{ App.currentYear }} : {{ App.texte.dateFoire }}
La répartition des enseignements sera terminée pour {{ App.currentYear }} - {{App.currentYear+1}}. Vous êtes tous conviés à un buffet qui aura lieu le {{ App.texte.dateFoire }} entre 11h30 et 14h00.

Après cette introduction, nous déclarons la foire {{ App.currentYear }} ouverte !
[http://foire.physique.univ-paris-diderot.fr/](http://foire.physique.univ-paris-diderot.fr/)

Si vous avez une question, surfez sur le site de la foire ; il y a beaucoup d'informations.

Si vous ne trouvez pas l'information, alors vous pouvez contacter [{{App.appMail}}](mailto:{{App.appMail}}), merci d'utiliser cette adresse temporaire, la messagerie de l'université Paris Cité nous posant beaucoup de problèmes en ce mement.


Bien à vous,

Olivier Cardoso et Raphaël Galicher, responsables de la répartition des enseignements à l'UFR de Physique.

{{ include('mailer/signature.md.twig') }}
